Welcome to SimpleChinese's documentation!
======================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   readme
   installation
   usage
   modules
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
