=====
Usage
=====

To use SimpleChinese in a project::

    import simplechinese
