simplechinese package
=====================

Submodules
----------

simplechinese.nlp module
------------------------

.. automodule:: simplechinese.nlp
   :members:
   :undoc-members:
   :show-inheritance:

simplechinese.preprocessing module
----------------------------------

.. automodule:: simplechinese.preprocessing
   :members:
   :undoc-members:
   :show-inheritance:

simplechinese.representation module
-----------------------------------

.. automodule:: simplechinese.representation
   :members:
   :undoc-members:
   :show-inheritance:

simplechinese.visualization module
----------------------------------

.. automodule:: simplechinese.visualization
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: simplechinese
   :members:
   :undoc-members:
   :show-inheritance:
