"""Unit test package for simplechinese."""
